import json
import boto3
from utils.pre_process import Preprocess

myPreProcessor = Preprocess(max_length_tweet_arg=40,\
    max_length_dictionary_arg=100000)

# sagemaker_client = boto3.client("runtime.sagemaker")

def lambda_handler(event, context):
    # TODO implement

    print (event)
 
    tweet = event["tweet"]
  
    features = myPreProcessor.one_for_all(tweet)

    model_payload = {
        'features': features
    }

    # model_response = sagemaker_client.invoke_endpoint(
    #             Endpointname="hwk5-endpoint-2",
    #             ContentType="application/json",
    #             BOdy=json.dumps(model_payload))

    # result = json.loads(model_response["Body"].read().decode())

    # response = {}

    # if result["predictions"][0][0] >= 0.5:
    #     response["sentiment"] = "positive"
    # else:
    #     response["sentiment"] = "negative"


    # print("Result: " + json.dumps(response, indent=2))

    return model_payload