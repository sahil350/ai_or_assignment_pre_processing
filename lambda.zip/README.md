# ai_or_assignment_pre_processing
Assignment 3 of the course AI and OR at scale
